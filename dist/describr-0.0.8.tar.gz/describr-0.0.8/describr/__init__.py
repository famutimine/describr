from .describr import FindOutliers, DescriptiveStats

__version__ = '0.0.8'

__all__ = ['FindOutliers', 'DescriptiveStats']
